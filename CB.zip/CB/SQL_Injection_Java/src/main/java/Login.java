import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

// @WebServlet("/login") - Using explicit mapping in web.xml instead
public class Login extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Database configuration
    private static final String DB_URL = "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "";
    
    @Override
    public void init() throws ServletException {
        super.init();
        initializeDatabase();
    }
    
    // Initialize in-memory database with sample data
    private void initializeDatabase() {
        try (Connection connection = getConnection()) {
            // Create users table
            String createTableSQL = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT PRIMARY KEY AUTO_INCREMENT, " +
                    "email VARCHAR(255) UNIQUE, " +
                    "password VARCHAR(255))";
            
            try (Statement stmt = connection.createStatement()) {
                stmt.execute(createTableSQL);
                
                // Insert sample users (using H2 compatible MERGE syntax)
                stmt.execute("MERGE INTO users (email, password) VALUES ('alice@bank.com', 'alice123')");
                stmt.execute("MERGE INTO users (email, password) VALUES ('bob@bank.com', 'bob456')");
            }
            
        } catch (SQLException e) {
            System.err.println("Database initialization failed: " + e.getMessage());
        }
    }
    
    // Get database connection
    private Connection getConnection() throws SQLException {
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("H2 driver not found", e);
        }
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Display login form
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Login Demo - SQL Injection Example</title></head>");
        out.println("<body>");
        out.println("<h2>SQL Injection Demo - Login Form</h2>");
        out.println("<p><strong>Test Credentials:</strong></p>");
        out.println("<ul><li>Email: alice@bank.com, Password: alice123</li>");
        out.println("<li>Email: bob@bank.com, Password: bob456</li></ul>");
        out.println("<p><strong>SQL Injection Test:</strong> Try password: <code>' or 1=1--</code></p>");
        
        out.println("<form method='post' action='login'>");
        out.println("Email: <input type='email' name='email' required><br><br>");
        out.println("Password: <input type='password' name='password' required><br><br>");
        out.println("<input type='submit' value='Login (Vulnerable)'> ");
        out.println("<input type='submit' name='secure' value='Login (Secure)'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Define the request.get parameter method to get the email, pass from user using Http request
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        boolean useSecure = request.getParameter("secure") != null;
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Login Result</title></head>");
        out.println("<body>");
        
        if (useSecure) {
            handleSecureLogin(email, password, out);
        } else {
            handleVulnerableLogin(email, password, out);
        }
        
        out.println("<br><a href='login'>Back to Login</a>");
        out.println("</body></html>");
    }
    
    private void handleVulnerableLogin(String email, String password, PrintWriter out) {
        // VULNERABLE SQL INJECTION EXAMPLE
        String sql = "select * from users where (email= '"+email+"' and password='"+password+"')";
        
        // Below is the raw query sent to the DB: 
        //"SELECT * FROM users WHERE (email = '""' AND password = '""')"
        // alice123'
       // Enter the password alice123' , how the single quote ' you appended is interpreted by the SQL server? 
       //It is interpreted as a string delimiter. So when the query is processed, 
       // the last quote does not have a closing/matching ' character, which causes a SQL syntax error, resulting in the HTTP 500 Internal Server Error
        // but alice123''  doesn't give any error 
        // Query: "SELECT * FROM users WHERE (email = 'alice@bank.com' AND password = 'alice123''')"
        
        out.println("<h2>VULNERABLE LOGIN ATTEMPT</h2>");
        out.println("<p><strong>Generated SQL Query:</strong></p>");
        out.println("<pre>" + sql + "</pre>");
        
        boolean loggedIn = false;
        
        try (Connection connection = getConnection();
             Statement statement = connection.createStatement()) {
            
            ResultSet result = statement.executeQuery(sql); //define execute query method for sql server retrun resultset

            if(result.next()) {
                loggedIn = true;
                out.println("<p style='color: green;'><strong>SUCCESS:</strong> Login successful!</p>");
                out.println("<p>Welcome, " + result.getString("email") + "!</p>");

            } else {
                out.println("<p style='color: red;'><strong>FAILED:</strong> Invalid credentials</p>");
                System.out.println("Failed to login");
            }
            
        } catch (SQLException e) {
            out.println("<p style='color: red;'><strong>SQL ERROR:</strong> " + e.getMessage() + "</p>");
            out.println("<p>This might be due to SQL injection attempt!</p>");
        }
    }
    
    private void handleSecureLogin(String email, String password, PrintWriter out) {
        // SECURE VERSION USING PREPARED STATEMENTS
        out.println("<h2>SECURE LOGIN ATTEMPT</h2>");
        out.println("<p><strong>Using Prepared Statement (SQL Injection Protected)</strong></p>");
        
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
        out.println("<p><strong>Prepared Statement Template:</strong></p>");
        out.println("<pre>" + sql + "</pre>");
        
        boolean loggedIn = false;
        
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            
            preparedStatement.setString(1, email);
            preparedStatement.setString(2, password);
            
            out.println("<p><strong>Parameters:</strong> email='" + email + "', password='[HIDDEN]'</p>");
            
            try (ResultSet result = preparedStatement.executeQuery()) {
                if(result.next()) {
                    loggedIn = true;
                    out.println("<p style='color: green;'><strong>SUCCESS:</strong> Login successful!</p>");
                    out.println("<p>Welcome, " + result.getString("email") + "!</p>");
                } else {
                    out.println("<p style='color: red;'><strong>FAILED:</strong> Invalid credentials</p>");
                }
            }
            
        } catch (SQLException e) {
            out.println("<p style='color: red;'><strong>ERROR:</strong> " + e.getMessage() + "</p>");
        }
    }
}

// Username: alice@bank.com

// Password: ' or 1=1)#

// The above resulted in the following SQL statement:
// SELECT UserID FROM User
// WHERE (email = 'alice@bank.com'
// AND password = '' OR 1=1)#

// Prepared statements (aka parameterized queries) are the best mechanism for preventing SQL injection attacks.

// Prepared statements are used to abstract SQL statement syntax from input parameters. Statement templates are first defined at the application layer, and the parameters are then passed to them.

// Finally, we execute our authentication query by invoking the preparedStatement.executeQuery() method. The SQL used by PreparedStatement is precompiled ensuring that all parameters sent to the underlying database are treated as literal values and not SQL statement/query language, ensuring that no SQL code can be injected using an untrusted parameter.

// Ultimately, the security payoff with using prepared statements is that the database will ensure the parameters are automatically escaped.
