# SQL Injection Demo - Java Web Application

This is a demonstration application that shows SQL injection vulnerabilities and their prevention using prepared statements in Java.

## 🚨 **IMPORTANT SECURITY NOTE**

This application contains **INTENTIONALLY VULNERABLE CODE** for educational purposes only. 
**DO NOT** use this code in production environments. It demonstrates both vulnerable and secure approaches to handling SQL queries.

## Features

- **Vulnerable Login**: Demonstrates SQL injection vulnerability using string concatenation
- **Secure Login**: Shows proper implementation using prepared statements
- **In-Memory Database**: Uses H2 database with sample user data
- **Real-time SQL Query Display**: Shows the actual SQL queries being executed
- **Educational Comments**: Includes detailed comments explaining security concepts

## Prerequisites

- Java 11 or higher
- Maven 3.6 or higher

## How to Run

### Option 1: Using Maven Jetty Plugin (Recommended)

```bash
# Compile and run the application
mvn clean compile jetty:run
```

Then open your browser and navigate to:
```
http://localhost:9091/sql-injection-demo/login
```

### Option 2: Using Maven Tomcat Plugin

```bash
# Compile and run with Tomcat
mvn clean compile tomcat7:run
```

### Option 3: Build WAR file and deploy

```bash
# Build the WAR file
mvn clean package

# The WAR file will be created at: target/sql-injection-demo.war
# Deploy this to any servlet container (Tomcat, Jetty, etc.)
```

## Test Credentials

The application comes with pre-loaded test users:

- **Email:** `alice@bank.com`, **Password:** `alice123`
- **Email:** `bob@bank.com`, **Password:** `bob456`

## SQL Injection Testing

### Vulnerable Login (Left Button)

Try these SQL injection payloads in the password field:

1. **Basic SQL Injection:**
   - Password: `' or 1=1--`
   - This should bypass authentication

2. **Comment-based Injection:**
   - Password: `' or '1'='1'--`
   - Uses SQL comments to ignore the rest of the query

3. **Union-based Injection:**
   - Password: `' UNION SELECT 1,1,1--`
   - Attempts to extract additional data

### Secure Login (Right Button)

The same payloads will fail against the secure implementation because:
- Parameters are properly escaped
- SQL structure is pre-defined
- User input cannot alter the query structure

## Educational Value

This application demonstrates:

1. **How SQL Injection Works**: Shows actual vulnerable code and the resulting SQL queries
2. **Why It's Dangerous**: Demonstrates authentication bypass
3. **How to Prevent It**: Shows proper use of prepared statements
4. **Real-world Impact**: Educational comments explain the security implications

## Original Comments Preserved

All educational comments from the original code have been preserved, including:

- Explanation of how single quotes are interpreted by SQL servers
- Examples of SQL injection payloads
- Description of prepared statements and their security benefits
- Commentary on parameter escaping

## Code Structure

```
src/
├── main/
│   ├── java/
│   │   └── Login.java          # Main servlet with both vulnerable and secure implementations
│   └── webapp/
│       ├── WEB-INF/
│       │   └── web.xml         # Web application configuration
│       └── error.html          # Error page
├── pom.xml                     # Maven build configuration
└── README.md                   # This file
```

## Security Learning Points

1. **String Concatenation = Danger**: Never build SQL queries using string concatenation with user input
2. **Prepared Statements = Safety**: Always use prepared statements for dynamic queries
3. **Parameter Binding**: Let the database handle parameter escaping automatically
4. **Input Validation**: Always validate and sanitize user input
5. **Least Privilege**: Database users should have minimal required permissions

## Stopping the Application

To stop the application:
- Press `Ctrl+C` in the terminal where the application is running

## Troubleshooting

### Port Already in Use
If port 9091 is already in use, you can specify a different port:
```bash
mvn jetty:run -Djetty.port=8082
```

### Java Version Issues
Ensure you're using Java 11 or higher:
```bash
java -version
mvn -version
```

### Database Connection Issues
The application uses an in-memory H2 database that's created automatically. No external database setup is required.

## Educational Use Only

**Remember:** This application is for educational purposes only. The vulnerable code demonstrates real security flaws that could be exploited by attackers. Always use secure coding practices in production applications.
